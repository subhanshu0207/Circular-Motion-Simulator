package utils;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.geom.Path2D;

public class GraphPanel extends JPanel {
    Dimension dimension;

    Color bgColor;
    Color graphColor;

    double scaleX = 7;
    double scaleY = 5;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D)g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        double offsetX = (20 / 2000.0) * getWidth();
        double offsetY = (20 / 2000.0) * getHeight();

        double originX = offsetX;
        double originY = dimension.height / 2.0;

        g2.setColor(graphColor);
        g2.setStroke(new BasicStroke(1.8f));
        plot(g2, originX, originY, offsetX);

        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(1f));
        drawAxes(g2, originX, originY, offsetX, offsetY);
    }

    private void drawAxes(Graphics2D g2, double originX, double originY, double offsetX, double offsetY) {
        //X-axis
        Vector.drawVector(
                g2,
                g2.getColor(),
                g2.getStroke(),
                originX,
                originY,
                (dimension.width - offsetX),
                originY,
                8
        );

        //Upward Y-axis
        Vector.drawVector(
                g2,
                g2.getColor(),
                g2.getStroke(),
                originX,
                originY,
                originX,
                offsetY,
                8
        );

        //Downward Y-axis
        Vector.drawVector(
                g2,
                g2.getColor(),
                g2.getStroke(),
                originX,
                originY,
                originX,
                (dimension.height - offsetY),
                8
        );
    }

    protected double calculate(double x) {
        return 0;
    }

    private void plot(Graphics2D g2, double originX, double originY, double offsetX) {
        Path2D path = new Path2D.Double();
        boolean firstPoint = true;

        for(double x = originX; x <= dimension.width - offsetX ; x += 0.1) {
            double y = originY - scaleY * calculate(((x - originX) / scaleX));

            if(firstPoint) {
                path.moveTo(x, y);
                firstPoint = false;
            }
            else
                path.lineTo(x, y);
        }

        g2.draw(path);
    }

    public GraphPanel(Dimension dimension, Color bgColor, Color graphColor) {
        this.dimension = dimension;
        this.bgColor = bgColor;
        this.graphColor = graphColor;

        setPreferredSize(dimension);
        setBackground(bgColor);
    }
}
